import math

from soar.sim.world import *

world = World(dimensions=(8, 2), initial_position=(0.5, 0.55, math.pi/12))
