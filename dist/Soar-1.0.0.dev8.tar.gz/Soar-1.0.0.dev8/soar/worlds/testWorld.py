from soar.sim.world import *

world = World(dimensions=(3, 4), initial_position=(1.5, 1.5, 0))

