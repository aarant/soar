from soar.sim.world import *

world = World(dimensions=(4.05, 4.05), initial_position=(1.0, 1.0, 0.0))
