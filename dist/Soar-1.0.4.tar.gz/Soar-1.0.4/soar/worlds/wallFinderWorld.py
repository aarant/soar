from soar.sim.world import *

world = World(dimensions=(3.0, 3.0), initial_position=(1.6, 1.5, 0))
