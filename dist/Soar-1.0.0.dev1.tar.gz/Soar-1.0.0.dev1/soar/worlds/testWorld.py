from soar.sim.world import *

world = World(dimensions=(3, 3), initial_position=(0.6, 1.5, 0),)
              #objects=[Wall((1.5, 0.5), (1.5, 1.49)), Wall((1.5, 1.51), (1.5, 2.5))])
