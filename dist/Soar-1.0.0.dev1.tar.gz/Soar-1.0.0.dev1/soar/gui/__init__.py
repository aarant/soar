""" Soar GUI Package

Contains the modules for building and displaying Soar's GUI, as well as all GIFs used for icons or animations, and
plot generation.
"""
from soar import __version__
