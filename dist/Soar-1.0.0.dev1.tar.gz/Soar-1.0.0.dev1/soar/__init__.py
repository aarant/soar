""" Soar (Snakes on a robot): A Python robotics framework.

An extensible Python framework for simulating and interacting with robots.

TODO: Sphinx default-role domain
"""
__version__ = '1.0.0.dev1'
