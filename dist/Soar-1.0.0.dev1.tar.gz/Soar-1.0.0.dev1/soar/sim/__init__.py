""" Soar simulator modules.

Contains geometry and world-related classes for simulation.
"""
