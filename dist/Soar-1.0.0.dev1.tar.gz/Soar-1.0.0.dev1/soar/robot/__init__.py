""" Soar robot modules, containing the BaseRobot class and an implementation of a Pioneer 3 robot. """
